import { query, mutation } from "./_generated/server";
import { internal } from "./_generated/api";
import { v } from "convex/values";

// -------------------- GET ALL CONTACTS --------------------
export const getAllContacts = query({
  handler: async (ctx) => {
    const currentUser = await ctx.runQuery(internal.users.getCurrentUser);

    // 1. Expenses paid by current user (personal only, no group)
    const expensesYouPaid = await ctx.db
      .query("expenses")
      .withIndex("by_user_and_group", (q) =>
        q.eq("paidByUserId", currentUser._id).eq("groupId", null)
      )
      .collect();

    // 2. Expenses not paid by you, but you are included in splits
    const expensesNotPaidByYou = (await ctx.db
      .query("expenses")
      .withIndex("by_group", (q) => q.eq("groupId", null))
      .collect()
    ).filter(
      (e) =>
        e.paidByUserId !== currentUser._id &&
        e.splits.some((s) => s.userId === currentUser._id)
    );

    const personalExpenses = [...expensesYouPaid, ...expensesNotPaidByYou];

    // 3. Collect all unique contact IDs
    const contactIds = new Set();
    personalExpenses.forEach((exp) => {
      if (exp.paidByUserId !== currentUser._id) {
        contactIds.add(exp.paidByUserId);
      }
      exp.splits.forEach((s) => {
        if (s.userId !== currentUser._id) contactIds.add(s.userId);
      });
    });

    // 4. Fetch user details for all contacts
    const contactUsers = await Promise.all(
      [...contactIds].map(async (id) => {
        const user = await ctx.db.get(id);
        return user
          ? {
              _id: user._id,
              name: user.name,
              email: user.email,
              imageUrl: user.imageUrl,
              type: "user",
            }
          : null;
      })
    );

    // 5. Get all groups where current user is a member
    const userGroups = (await ctx.db.query("groups").collect())
      .filter((g) =>
        g.members.some((m) => m.userId === currentUser._id)
      )
      .map((g) => ({
        _id: g._id,
        name: g.name,
        description: g.description,
        memberCount: g.members.length,
        type: "group",
      }));

    // 6. Sort results
    contactUsers.sort((a, b) => a?.name?.localeCompare(b?.name ?? ""));
    userGroups.sort((a, b) => a.name.localeCompare(b.name));

    return {
      users: contactUsers.filter(Boolean),
      groups: userGroups,
    };
  },
});

// -------------------- CREATE GROUP --------------------
export const createGroup = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    members: v.array(v.id("users")),
  },
  handler: async (ctx, args) => {
    const currentUser = await ctx.runQuery(internal.users.getCurrentUser);

    if (!args.name.trim()) {
      throw new Error("Group name is required");
    }

    // Always include the creator
    const uniqueMembers = new Set([...args.members, currentUser._id]);

    // Validate all members exist
    for (const memberId of uniqueMembers) {
      const user = await ctx.db.get(memberId);
      if (!user) {
        throw new Error(`User with ID ${memberId} does not exist`);
      }
    }

    // Insert group
    const groupId = await ctx.db.insert("groups", {
      name: args.name.trim(),
      description: args.description?.trim() ?? "",
      members: [...uniqueMembers].map((id) => ({
        userId: id,
        role: id === currentUser._id ? "admin" : "member",
        joinedAt: Date.now(),
      })),
      createdBy: currentUser._id,
      createdAt: Date.now(),
    });

    return groupId;
  },
});
